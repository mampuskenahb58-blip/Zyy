// config.js
export default {
  botName: "CYBIX V1 ZYY",
  prefix: ".",
  owner: "t.me/ZyyPridee",
  OWNER_ID: process.env.OWNER_ID || "8227430620",
  channels: {
    whatsapp: "https://whatsapp.com/channel/0029VbB8svo6",
    telegram: "https://t.me/KYNZYSTORE"
  },
  banner: "https://i.postimg.cc/L4NwW5WY/boykaxd.jpg",
  botToken: process.env.BOT_TOKEN
};